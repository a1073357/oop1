public class A1073357_0331 {

    public static void main(String[] argv) throws Exception {

        animal olaf = new Olaf();
        animal sven = new Sven();
        human kristoff = new Kristoff();
        human hans = new Hans();
        human anna = new Anna();
        human elsa = new Elsa();

        animal.showinfo();
        olaf.show();
        sven.show();
        kristoff.show();
        hans.show();
        anna.show();
        elsa.show();

    }

}